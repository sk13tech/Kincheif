import { useState, useEffect, useMemo } from 'react';
import { db } from '../lib/firebase';
import { getAuth, signInWithEmailAndPassword, signOut, onAuthStateChanged, type User } from 'firebase/auth';
import { collection, doc, getDoc, getDocs, updateDoc, deleteDoc, setDoc, onSnapshot } from 'firebase/firestore';
import { LayoutDashboard, Package, ShoppingCart, Users, Settings, LogOut, Lock, Loader2, X, Plus, Trash2, Save, ArrowLeft, ChevronRight, Search, AlertTriangle, Download, Clock, MapPin, CreditCard, Edit3, UserCheck, ShoppingBag, TrendingUp, AlertCircle, CheckCircle, RotateCcw, Truck, Phone, CalendarDays, Menu as MenuIcon } from 'lucide-react';
import { initializeApp } from 'firebase/app';

/* ═══ Separate Auth for Admin (doesn't touch user Google session) ═══ */
const adminApp = initializeApp({
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
}, 'admin-auth');
const adminAuth = getAuth(adminApp);

/* ═══ Design Tokens ═══ */
const cn = (...c: (string | false | undefined)[]) => c.filter(Boolean).join(' ');
const card = 'bg-white rounded-2xl border border-slate-200/80 shadow-sm';
const input = 'w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-sm text-slate-800 outline-none focus:ring-2 focus:ring-emerald-500/30 focus:border-emerald-500 placeholder:text-slate-400';
const label = 'block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5';
const btn1 = 'bg-emerald-600 text-white text-sm font-semibold px-5 py-2.5 rounded-xl hover:bg-emerald-700 active:scale-[0.97] transition-all disabled:opacity-40 inline-flex items-center gap-2';
const btn2 = 'bg-slate-100 text-slate-700 text-sm font-medium px-4 py-2.5 rounded-xl hover:bg-slate-200 active:scale-[0.97] transition-all inline-flex items-center gap-2';

const badge = (color: string) => `inline-flex items-center text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full ${color}`;
const statusStyle: Record<string, string> = {
  pending: 'bg-amber-100 text-amber-700', confirmed: 'bg-blue-100 text-blue-700', processing: 'bg-violet-100 text-violet-700',
  preparing: 'bg-violet-100 text-violet-700', shipped: 'bg-indigo-100 text-indigo-700', delivered: 'bg-emerald-100 text-emerald-700', cancelled: 'bg-red-100 text-red-700',
};
function fmt(d: string) { return d ? new Date(d).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : '—'; }
function money(n: number) { return `₹${(n || 0).toLocaleString('en-IN')}`; }
const statuses = ['pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled'];

/* ═══ CSV Export ═══ */
function downloadCSV(rows: Record<string, any>[], filename: string) {
  if (!rows.length) return;
  const keys = Object.keys(rows[0]);
  const csv = [keys.join(','), ...rows.map(r => keys.map(k => `"${String(r[k] ?? '').replace(/"/g, '""')}"`).join(','))].join('\n');
  const blob = new Blob([csv], { type: 'text/csv' });
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = filename; a.click();
}

/* ═══════════════════════════════════════════
   LOGIN SCREEN
   ═══════════════════════════════════════════ */
function LoginScreen() {
  const [email, setEmail] = useState(''); const [pass, setPass] = useState(''); const [err, setErr] = useState(''); const [busy, setBusy] = useState(false);
  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setBusy(true); setErr('');
    try {
      const c = await signInWithEmailAndPassword(adminAuth, email, pass);
      const snap = await getDoc(doc(db, 'config', 'admins'));
      if (!snap.exists() || !snap.data().uids?.includes(c.user.uid)) { await signOut(adminAuth); setErr('Access denied. Not an admin.'); }
    } catch (ex: any) {
      setErr(ex.code === 'auth/invalid-credential' ? 'Invalid email or password' : ex.code === 'auth/too-many-requests' ? 'Too many attempts. Try later.' : 'Login failed');
    }
    setBusy(false);
  };
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-emerald-50/30 px-4">
      <form onSubmit={submit} className={`${card} w-full max-w-sm p-8 space-y-5`}>
        <div className="text-center">
          <div className="h-14 w-14 rounded-2xl bg-emerald-600 flex items-center justify-center mx-auto mb-4 shadow-lg shadow-emerald-200"><Lock className="h-7 w-7 text-white" /></div>
          <h1 className="text-xl font-bold text-slate-900">Admin Panel</h1>
          <p className="text-sm text-slate-500 mt-1">Admin Management</p>
        </div>
        <div><label className={label}>Email</label><input type="email" value={email} onChange={e => setEmail(e.target.value)} required className={input} placeholder="admin@yoursite.com" /></div>
        <div><label className={label}>Password</label><input type="password" value={pass} onChange={e => setPass(e.target.value)} required className={input} placeholder="••••••••" /></div>
        {err && <div className="flex items-center gap-2 text-sm text-red-600 bg-red-50 rounded-xl px-3 py-2"><AlertCircle className="h-4 w-4 flex-shrink-0" />{err}</div>}
        <button type="submit" disabled={busy} className={`${btn1} w-full justify-center !py-3`}>{busy ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Sign In'}</button>
      </form>
    </div>
  );
}

/* ═══════════════════════════════════════════
   DASHBOARD
   ═══════════════════════════════════════════ */
function Dashboard({ goTo }: { goTo: (p: string) => void }) {
  const [s, setS] = useState({ orders: 0, revenue: 0, products: 0, customers: 0, pending: 0, confirmed: 0, processing: 0, shipped: 0, delivered: 0, replacement: 0 });
  const [recent, setRecent] = useState<any[]>([]);
  const [busy, setBusy] = useState(true);
  const [dupTxns, setDupTxns] = useState<string[]>([]);
  const [dupDismissed, setDupDismissed] = useState(false);

  useEffect(() => {
    let productCount = 0; let contactCount = 0; let countsLoaded = false;
    // Load counts once
    Promise.all([getDocs(collection(db, 'products')), getDocs(collection(db, 'contacts'))]).then(([p, c]) => {
      productCount = p.size; contactCount = c.size; countsLoaded = true;
    });
    // Real-time orders
    const unsub = onSnapshot(collection(db, 'orders'), (snap) => {
      const st: any = { orders: snap.size, revenue: 0, products: productCount, customers: contactCount, pending: 0, confirmed: 0, processing: 0, shipped: 0, delivered: 0, replacement: 0 };
      const all: any[] = []; const txns: Record<string, number> = {};
      snap.forEach(d => { const x = d.data(); if (x.status !== 'cancelled') { st.revenue += x.totalAmount || 0; st[x.status] = (st[x.status] || 0) + 1; } if (x.replacementRequested && x.replacementStatus !== 'reshipped') st.replacement++; all.push({ id: d.id, ...x });
        if (x.transactionId && x.transactionId !== 'GIFTCARD' && x.status !== 'cancelled') txns[x.transactionId] = (txns[x.transactionId] || 0) + 1;
      });
      all.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      // Single batch state update — no flickering
      setS({ ...st }); setRecent(all.slice(0, 5));
      setDupTxns(Object.entries(txns).filter(([_, c]) => c > 1).map(([t]) => t));
      if (countsLoaded || snap.size > 0) setBusy(false);
    });
    return () => unsub();
  }, []);

  const stats = [
    { label: 'Revenue', value: money(s.revenue), icon: TrendingUp, color: 'text-emerald-600 bg-emerald-50', page: 'orders' },
    { label: 'Orders', value: s.orders, icon: ShoppingBag, color: 'text-blue-600 bg-blue-50', page: 'orders' },
    { label: 'Pending', value: s.pending, icon: Clock, color: 'text-amber-600 bg-amber-50', page: 'orders' },
    { label: 'Delivered', value: s.delivered, icon: CheckCircle, color: 'text-emerald-600 bg-emerald-50', page: 'orders' },
    { label: 'Products', value: s.products, icon: Package, color: 'text-violet-600 bg-violet-50', page: 'products' },
    { label: 'Customers', value: s.customers, icon: Users, color: 'text-sky-600 bg-sky-50', page: 'customers' },
  ];

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-slate-900">Dashboard</h1>

      {/* Fraud alert — dismissible */}
      {dupTxns.length > 0 && !dupDismissed && (
        <div className="flex items-start gap-3 bg-red-50 border border-red-200 rounded-2xl px-5 py-4">
          <AlertTriangle className="h-5 w-5 text-red-500 mt-0.5 flex-shrink-0" />
          <div className="flex-1"><p className="text-sm font-semibold text-red-800">Duplicate Transaction IDs Detected</p><p className="text-xs text-red-600 mt-0.5">{dupTxns.join(', ')}</p></div>
          <button onClick={() => setDupDismissed(true)} className="h-6 w-6 rounded-lg flex items-center justify-center hover:bg-red-100 flex-shrink-0"><X className="h-4 w-4 text-red-400" /></button>
        </div>
      )}

      {/* Stats grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
        {stats.map(s => (
          <button key={s.label} onClick={() => goTo(s.page)} className={`${card} p-5 text-left hover:shadow-md transition-shadow group`}>
            <div className={`h-10 w-10 rounded-xl ${s.color} flex items-center justify-center mb-3`}><s.icon className="h-5 w-5" /></div>
            <p className="text-2xl font-bold text-slate-900">{busy ? <span className="inline-block h-7 w-16 bg-slate-100 rounded animate-pulse" /> : s.value}</p>
            <p className="text-xs text-slate-400 mt-0.5 group-hover:text-emerald-600 transition-colors">{s.label} →</p>
          </button>
        ))}
      </div>

      {/* Recent orders */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider">Recent Orders</h2>
          <button onClick={() => goTo('orders')} className="text-xs text-emerald-600 font-semibold hover:text-emerald-700 flex items-center gap-1">View All <ChevronRight className="h-3 w-3" /></button>
        </div>
        <div className={`${card} overflow-hidden divide-y divide-slate-100`}>
          {recent.map(o => (
            <div key={o.id} className="px-5 py-3 flex items-center gap-3 text-sm hover:bg-slate-50/50">
              <span className="font-mono text-xs text-slate-400 w-20 flex-shrink-0 truncate">#{o.orderId || o.id.slice(-6)}</span>
              <span className="flex-1 truncate text-slate-700 font-medium">{o.customer?.name || '—'}</span>
              <span className="font-semibold text-slate-900">{money(o.totalAmount)}</span>
              <span className={badge(statusStyle[o.status] || 'bg-slate-100 text-slate-600')}>{o.status}</span>
            </div>
          ))}
          {recent.length === 0 && <p className="p-8 text-center text-sm text-slate-400">No orders yet</p>}
        </div>
      </div>

      {/* Pie Chart — All statuses except cancelled */}
      {!busy && s.orders > 0 && (() => {
        const allSlices = [
          { label: 'Pending', value: s.pending, color: '#f59e0b' },
          { label: 'Confirmed', value: s.confirmed, color: '#3b82f6' },
          { label: 'Processing', value: s.processing, color: '#14b8a6' },
          { label: 'Shipped', value: (s as any).shipped || 0, color: '#6366f1' },
          { label: 'Delivered', value: s.delivered, color: '#10b981' },
          { label: 'Replacement', value: (s as any).replacement || 0, color: '#8b5cf6' },
        ];
        // Only show slices with value > 0 in the chart, but list all in legend
        const slices = allSlices.filter(sl => sl.value > 0);
        const total = slices.reduce((sum, sl) => sum + sl.value, 0) || 1;
        let cumulative = 0;
        const paths = slices.map(sl => {
          const start = cumulative / total;
          const end = (cumulative + sl.value) / total;
          cumulative += sl.value;
          const startAngle = start * 2 * Math.PI - Math.PI / 2;
          const endAngle = end * 2 * Math.PI - Math.PI / 2;
          const largeArc = sl.value / total > 0.5 ? 1 : 0;
          const x1 = 50 + 40 * Math.cos(startAngle), y1 = 50 + 40 * Math.sin(startAngle);
          const x2 = 50 + 40 * Math.cos(endAngle), y2 = 50 + 40 * Math.sin(endAngle);
          return { ...sl, d: slices.length === 1 ? `M50,10 A40,40 0 1,1 49.99,10 Z` : `M50,50 L${x1},${y1} A40,40 0 ${largeArc},1 ${x2},${y2} Z`, pct: Math.round(sl.value / total * 100) };
        });
        return (
          <div>
            <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-3">Business Overview</h2>
            <div className={`${card} p-6 flex flex-col sm:flex-row items-center gap-6`}>
              <svg viewBox="0 0 100 100" className="h-36 w-36 flex-shrink-0">
                {paths.map((p, i) => <path key={i} d={p.d} fill={p.color} className="hover:opacity-80 transition-opacity" />)}
                <circle cx="50" cy="50" r="20" fill="white" />
                <text x="50" y="48" textAnchor="middle" className="text-[8px] font-bold fill-slate-900">{total}</text>
                <text x="50" y="56" textAnchor="middle" className="text-[5px] fill-slate-400 uppercase">orders</text>
              </svg>
              <div className="flex-1 grid grid-cols-2 gap-3 w-full">
                {allSlices.map((sl, i) => (
                  <div key={i} className="flex items-center gap-2.5">
                    <div className="h-3 w-3 rounded-full flex-shrink-0" style={{ backgroundColor: sl.color, opacity: sl.value > 0 ? 1 : 0.3 }} />
                    <div><p className="text-sm font-semibold text-slate-800">{sl.value} <span className="text-slate-400 font-normal">({total > 0 ? Math.round(sl.value / total * 100) : 0}%)</span></p><p className="text-[10px] text-slate-400">{sl.label}</p></div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        );
      })()}
    </div>
  );
}

/* ═══ Refund Component ═══ */
function RefundSection({ orderId, amount, onDone }: { orderId: string; amount: number; onDone: () => void }) {
  const [txn, setTxn] = useState('');
  const [busy, setBusy] = useState(false);
  const process = async () => {
    if (!txn.trim() || txn.length < 4) return;
    setBusy(true);
    await updateDoc(doc(db, 'orders', orderId), { refundTxnId: txn.trim(), refundedAt: new Date().toISOString(), refundAmount: amount });
    setBusy(false); onDone();
  };
  return (
    <div className={`${card} p-5 space-y-3`}>
      <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Process Refund</p>
      <p className="text-sm text-slate-600">Refund <span className="font-bold text-slate-900">{money(amount)}</span> to customer</p>
      <div><label className={label}>Refund Transaction ID</label><input value={txn} onChange={e => setTxn(e.target.value)} placeholder="Enter UPI refund txn ID" className={input} /></div>
      <button onClick={process} disabled={busy || txn.length < 4} className={btn1}>
        {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <CreditCard className="h-4 w-4" />} Mark as Refunded
      </button>
    </div>
  );
}

/* ═══════════════════════════════════════════
   ORDERS (search, filter, detail, status update, CSV export, fraud detection)
   ═══════════════════════════════════════════ */
function Orders() {
  const [orders, setOrders] = useState<any[]>([]); const [sel, setSel] = useState<any>(null); const [filter, setFilter] = useState('all'); const [search, setSearch] = useState(''); const [updating, setUpdating] = useState(false);
  const [dateFrom, setDateFrom] = useState(''); const [dateTo, setDateTo] = useState('');

  useEffect(() => onSnapshot(collection(db, 'orders'), s => { const a: any[] = []; s.forEach(d => a.push({ id: d.id, ...d.data() })); a.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()); setOrders(a); }), []);

  const txnCounts = useMemo(() => { const m: Record<string, number> = {}; orders.forEach(o => { if (o.transactionId && o.transactionId !== 'GIFTCARD' && o.status !== 'cancelled') m[o.transactionId] = (m[o.transactionId] || 0) + 1; }); return m; }, [orders]);

  const filtered = orders.filter(o => {
    if (filter !== 'all' && o.status !== filter) return false;
    if (dateFrom && new Date(o.createdAt) < new Date(dateFrom)) return false;
    if (dateTo && new Date(o.createdAt) > new Date(dateTo + 'T23:59:59')) return false;
    if (!search) return true;
    const q = search.toLowerCase();
    return [o.customer?.name, o.customer?.email, o.customer?.phone, o.orderId, o.transactionId, o.id].some(f => f?.toLowerCase?.()?.includes(q));
  });

  const [shippingTrackId, setShippingTrackId] = useState('');
  const [showShipModal, setShowShipModal] = useState<string | null>(null);

  const changeStatus = async (id: string, status: string, extra?: Record<string, any>) => {
    setUpdating(true);
    const u: any = { status, [`status_${status}_at`]: new Date().toISOString(), ...extra };
    if (status === 'delivered') u.deliveredAt = new Date().toISOString();
    if (status === 'confirmed') u.confirmedAt = new Date().toISOString();
    if (status === 'processing') u.processingAt = new Date().toISOString();
    if (['shipped', 'delivered'].includes(status)) u.canCancel = false;
    await updateDoc(doc(db, 'orders', id), u);
    setSel((p: any) => p ? { ...p, status, ...u } : null);
    setUpdating(false);
    setShowShipModal(null);
    setShippingTrackId('');
  };

  const handleStatusChange = (id: string, newStatus: string) => {
    if (newStatus === 'shipped') { setShowShipModal(id); return; }
    changeStatus(id, newStatus);
  };

  const exportCSV = () => {
    downloadCSV(filtered.map(o => ({ OrderID: o.orderId || o.id.slice(-8), Customer: o.customer?.name, Email: o.customer?.email, Phone: o.customer?.phone, Total: o.totalAmount, Status: o.status, TxnID: o.transactionId, Date: o.createdAt })), 'orders.csv');
  };

  // Detail view
  if (sel) return (
    <div className="space-y-4">
      <button onClick={() => setSel(null)} className="flex items-center gap-1.5 text-sm text-slate-500 hover:text-slate-900"><ArrowLeft className="h-4 w-4" /> All Orders</button>
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div><p className="text-xs font-mono text-slate-400">#{sel.orderId || sel.id.slice(-8)}</p><p className="text-xs text-slate-400">{fmt(sel.createdAt)}</p></div>
        <div className="flex items-center gap-2">
          <span className={badge(statusStyle[sel.status] || '')}>{sel.status}</span>
          <select value={sel.status} onChange={e => handleStatusChange(sel.id, e.target.value)} disabled={updating} className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-sm outline-none focus:ring-2 focus:ring-emerald-500/30">
            {statuses.map(s => <option key={s} value={s}>{s.charAt(0).toUpperCase() + s.slice(1)}</option>)}
          </select>
          {(txnCounts[sel.transactionId] || 0) > 1 && <span className={badge('bg-red-100 text-red-700')}>Duplicate TXN</span>}
        </div>
      </div>

      <div className="grid sm:grid-cols-2 gap-4">
        <div className={`${card} p-5`}><p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1.5"><UserCheck className="h-3.5 w-3.5" /> Customer</p>
          <p className="text-sm font-bold text-slate-900">{sel.customer?.name}</p>
          <p className="text-xs text-slate-500 mt-0.5">{sel.customer?.email}</p>
          <p className="text-xs text-slate-500">{sel.customer?.phone}</p>
        </div>
        <div className={`${card} p-5`}><p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1.5"><MapPin className="h-3.5 w-3.5" /> Delivery</p>
          <p className="text-sm text-slate-700">{sel.customer?.address}</p>
          <p className="text-xs text-slate-500">{sel.customer?.city}, {sel.customer?.state} — {sel.customer?.pincode}</p>
        </div>
      </div>

      <div className={`${card} p-5`}><p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">Items</p>
        <div className="space-y-2">{sel.items?.map((it: any, i: number) => (
          <div key={i} className="flex items-center gap-3"><img src={it.image} alt="" className="h-10 w-10 rounded-xl object-cover border border-slate-200" />
            <div className="flex-1 min-w-0"><p className="text-sm font-medium text-slate-800 truncate">{it.name}</p><p className="text-xs text-slate-400">{it.qty} × {money(it.price)}</p></div>
            <p className="text-sm font-bold text-slate-900">{money(it.price * it.qty)}</p>
          </div>
        ))}</div>
      </div>

      <div className={`${card} p-5 space-y-2 text-sm`}><p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1.5"><CreditCard className="h-3.5 w-3.5" /> Payment</p>
        {sel.mrpTotal > 0 && <div className="flex justify-between text-slate-500"><span>MRP</span><span>{money(sel.mrpTotal)}</span></div>}
        {sel.productDiscount > 0 && <div className="flex justify-between text-emerald-600 font-medium"><span>Discount</span><span>−{money(sel.productDiscount)}</span></div>}
        {sel.couponCode && <div className="flex justify-between text-emerald-600 font-medium"><span>Coupon ({sel.couponCode})</span><span>−{money(sel.couponDiscount)}</span></div>}
        {sel.giftCardCode && <div className="flex justify-between text-teal-600 font-medium"><span>Gift Card ({sel.giftCardCode})</span><span>−{money(sel.giftCardUsed)}</span></div>}
        {sel.transactionId && sel.transactionId !== 'GIFTCARD' && <div className="flex justify-between text-slate-500"><span>Txn ID</span><span className="font-mono text-xs bg-slate-100 px-2 py-0.5 rounded">{sel.transactionId}</span></div>}
        <div className="border-t border-slate-100 pt-2 flex justify-between text-base font-bold text-slate-900"><span>Total Paid</span><span>{money(sel.totalAmount)}</span></div>
        {sel.refundTxnId && <div className="flex justify-between text-emerald-600 font-medium text-sm mt-1"><span>Refund TXN</span><span className="font-mono text-xs">{sel.refundTxnId}</span></div>}
      </div>

      {/* Refund section for cancelled orders */}
      {sel.status === 'cancelled' && !sel.refundTxnId && sel.totalAmount > 0 && (
        <RefundSection orderId={sel.id} amount={sel.totalAmount} onDone={() => setSel({ ...sel, refundTxnId: 'pending' })} />
      )}
      {sel.status === 'cancelled' && sel.refundTxnId && (
        <div className={`${card} p-4 flex items-center gap-3`}>
          <CheckCircle className="h-5 w-5 text-emerald-500 flex-shrink-0" />
          <div><p className="text-sm font-semibold text-emerald-700">Refund Processed</p><p className="text-xs text-slate-500 font-mono">{sel.refundTxnId}</p></div>
        </div>
      )}

      {/* Tracking ID + link if shipped */}
      {sel.trackingId && (
        <div className={`${card} p-4`}>
          <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">Tracking</p>
          <p className="text-sm font-mono text-slate-800">{sel.trackingId}</p>
          {sel.trackingLink && <a href={sel.trackingLink} target="_blank" rel="noopener noreferrer" className="text-xs text-emerald-600 font-semibold hover:underline mt-1 inline-block">Open tracking link →</a>}
        </div>
      )}

      {/* Shipping tracking modal */}
      {showShipModal === sel.id && (
        <div className={`${card} p-5 space-y-3`}>
          <p className="text-sm font-bold text-slate-900">Enter Shipping Details</p>
          <div><label className={label}>Tracking ID</label><input value={shippingTrackId} onChange={e => setShippingTrackId(e.target.value)} placeholder="Enter courier tracking ID" className={input} /></div>
          <div><label className={label}>Tracking Link (optional)</label><input value={(sel as any)._trackLink || ''} onChange={e => setSel({ ...sel, _trackLink: e.target.value })} placeholder="https://courier.com/track/..." className={input} /></div>
          <div className="flex gap-2">
            <button onClick={() => changeStatus(sel.id, 'shipped', { trackingId: shippingTrackId || null, trackingLink: (sel as any)._trackLink || null })} disabled={updating} className={btn1}>{updating ? <Loader2 className="h-4 w-4 animate-spin" /> : <Truck className="h-4 w-4" />} Mark Shipped</button>
            <button onClick={() => { setShowShipModal(null); setShippingTrackId(''); }} className={btn2}>Cancel</button>
          </div>
        </div>
      )}
    </div>
  );

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between"><h1 className="text-2xl font-bold text-slate-900">Orders</h1>
        <button onClick={exportCSV} className={btn2}><Download className="h-4 w-4" /> Export CSV</button>
      </div>
      {/* Filter tabs */}
      <div className="flex gap-1.5 overflow-x-auto scrollbar-none pb-1">
        {['all', ...statuses].map(s => (<button key={s} onClick={() => setFilter(s)} className={cn('px-3.5 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-colors', filter === s ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-500 hover:bg-slate-200')}>{s === 'all' ? `All (${orders.length})` : `${s} (${orders.filter(o => o.status === s).length})`}</button>))}
      </div>
      {/* Search */}
      <div className="relative"><Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" /><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search name, email, phone, order ID, txn ID…" className={`${input} pl-10`} /></div>
      {/* Date filter */}
      <div className="flex items-center gap-2 flex-wrap">
        <CalendarDays className="h-4 w-4 text-slate-400 flex-shrink-0" />
        <input type="date" value={dateFrom} onChange={e => setDateFrom(e.target.value)} className={`${input} !w-auto !max-w-[150px]`} />
        <span className="text-xs text-slate-400">to</span>
        <input type="date" value={dateTo} onChange={e => setDateTo(e.target.value)} className={`${input} !w-auto !max-w-[150px]`} />
        {(dateFrom || dateTo) && <button onClick={() => { setDateFrom(''); setDateTo(''); }} className="text-xs text-red-500 font-medium">Clear</button>}
      </div>
      {/* List */}
      <div className={`${card} overflow-hidden divide-y divide-slate-100`}>
        {filtered.length === 0 && <p className="p-10 text-center text-sm text-slate-400">No orders found</p>}
        {filtered.map(o => (
          <button key={o.id} onClick={() => setSel(o)} className="w-full text-left px-5 py-3.5 flex items-center gap-3 hover:bg-slate-50/80 transition-colors">
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-0.5">
                <span className="text-xs font-mono text-slate-400">#{o.orderId || o.id.slice(-6)}</span>
                <span className={badge(statusStyle[o.status] || '')}>{o.status}</span>
                {(txnCounts[o.transactionId] || 0) > 1 && <span className={badge('bg-red-100 text-red-700')}>Dup TXN</span>}
              </div>
              <p className="text-sm font-semibold text-slate-800 truncate">{o.customer?.name} · {o.items?.length} items · {money(o.totalAmount)}</p>
              <p className="text-xs text-slate-400">{fmt(o.createdAt)}</p>
            </div>
            <ChevronRight className="h-4 w-4 text-slate-300 flex-shrink-0" />
          </button>
        ))}
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════
   PRODUCTS CRUD
   ═══════════════════════════════════════════ */
function Products() {
  const [items, setItems] = useState<any[]>([]); const [edit, setEdit] = useState<any>(null); const [form, setForm] = useState<any>({}); const [busy, setBusy] = useState(false); const [searchQ, setSearchQ] = useState('');
  useEffect(() => onSnapshot(collection(db, 'products'), s => { const a: any[] = []; s.forEach(d => a.push({ id: d.id, ...d.data() })); setItems(a); }), []);

  const blank = { name: '', description: '', longDescription: '', price: '', originalPrice: '', image: '', images: '', category: '', tags: '', weight: '', ingredients: '', shelfLife: '', maxOrderLimit: '', inStock: true, isNew: false, isBestseller: false, rating: '4.5', reviews: '0' };
  const startNew = () => { setForm({ ...blank }); setEdit('new'); };
  const startEdit = (p: any) => { setForm({ ...p, images: (p.images || []).join(', '), tags: (p.tags || []).join(', '), ingredients: (p.ingredients || []).join(', '), price: String(p.price || ''), originalPrice: String(p.originalPrice || ''), maxOrderLimit: String(p.maxOrderLimit || ''), rating: String(p.rating || '4.5'), reviews: String(p.reviews || '0') }); setEdit(p); };

  const save = async () => {
    setBusy(true);
    const d: any = { ...form, price: Number(form.price) || 0, originalPrice: Number(form.originalPrice) || null, maxOrderLimit: Number(form.maxOrderLimit) || null, rating: Number(form.rating) || 4.5, reviews: Number(form.reviews) || 0,
      images: form.images ? form.images.split(',').map((s: string) => s.trim()).filter(Boolean) : [],
      tags: form.tags ? form.tags.split(',').map((s: string) => s.trim()).filter(Boolean) : [],
      ingredients: form.ingredients ? form.ingredients.split(',').map((s: string) => s.trim()).filter(Boolean) : [] };
    delete d.id;
    if (edit === 'new') { const id = d.name.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '') + '-' + Date.now().toString(36); d.id = id; await setDoc(doc(db, 'products', id), d); }
    else await updateDoc(doc(db, 'products', edit.id), d);
    setBusy(false); setEdit(null);
  };

  const filtered = items.filter(p => !searchQ || p.name?.toLowerCase().includes(searchQ.toLowerCase()));

  const F = (l: string, k: string, opts?: { type?: string; full?: boolean; area?: boolean }) => (
    <div className={opts?.full ? 'sm:col-span-2' : ''}><label className={label}>{l}</label>
      {opts?.area ? <textarea value={form[k] || ''} onChange={e => setForm({ ...form, [k]: e.target.value })} rows={3} className={`${input} resize-none`} /> :
        <input type={opts?.type || 'text'} value={form[k] || ''} onChange={e => setForm({ ...form, [k]: e.target.value })} className={input} />}
    </div>
  );

  if (edit !== null) return (
    <div className="space-y-4">
      <button onClick={() => setEdit(null)} className="flex items-center gap-1.5 text-sm text-slate-500 hover:text-slate-900"><ArrowLeft className="h-4 w-4" /> Back</button>
      <h1 className="text-2xl font-bold text-slate-900">{edit === 'new' ? 'Add Product' : 'Edit Product'}</h1>
      <div className={`${card} p-6 max-w-2xl`}>
        <div className="grid sm:grid-cols-2 gap-4">
          {F('Name', 'name')}{F('Category', 'category')}{F('Short Description', 'description', { full: true })}{F('Long Description', 'longDescription', { full: true, area: true })}
          {F('Price ₹', 'price', { type: 'number' })}{F('MRP ₹', 'originalPrice', { type: 'number' })}{F('Weight', 'weight')}{F('Shelf Life', 'shelfLife')}{F('Max Order Limit', 'maxOrderLimit', { type: 'number' })}
          {F('Main Image URL', 'image', { full: true })}{F('Gallery (comma URLs)', 'images', { full: true })}{F('Tags (comma)', 'tags', { full: true })}{F('Ingredients (comma)', 'ingredients', { full: true })}
        </div>
        {form.image && <img src={form.image} alt="" className="mt-3 h-20 w-20 rounded-xl object-cover border border-slate-200" />}
        <div className="flex gap-5 mt-5">
          <label className="flex items-center gap-2 text-sm font-medium text-slate-700"><input type="checkbox" checked={form.inStock} onChange={e => setForm({ ...form, inStock: e.target.checked })} className="accent-emerald-600 h-4 w-4" /> In Stock</label>
          <label className="flex items-center gap-2 text-sm font-medium text-slate-700"><input type="checkbox" checked={form.isNew} onChange={e => setForm({ ...form, isNew: e.target.checked })} className="accent-emerald-600 h-4 w-4" /> New</label>
          <label className="flex items-center gap-2 text-sm font-medium text-slate-700"><input type="checkbox" checked={form.isBestseller} onChange={e => setForm({ ...form, isBestseller: e.target.checked })} className="accent-emerald-600 h-4 w-4" /> Bestseller</label>
        </div>
        <div className="mt-6 flex gap-3"><button onClick={save} disabled={busy || !form.name} className={btn1}>{busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />} {edit === 'new' ? 'Create' : 'Update'}</button><button onClick={() => setEdit(null)} className={btn2}>Cancel</button></div>
      </div>
    </div>
  );

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between"><h1 className="text-2xl font-bold text-slate-900">Products ({items.length})</h1><button onClick={startNew} className={btn1}><Plus className="h-4 w-4" /> Add Product</button></div>
      <div className="relative"><Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" /><input value={searchQ} onChange={e => setSearchQ(e.target.value)} placeholder="Search products…" className={`${input} pl-10`} /></div>
      <div className={`${card} overflow-hidden divide-y divide-slate-100`}>
        {filtered.map(p => (
          <div key={p.id} className="px-5 py-3.5 flex items-center gap-4 hover:bg-slate-50/50">
            <img src={p.image} alt="" className="h-12 w-12 rounded-xl object-cover border border-slate-200 flex-shrink-0" />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-slate-800 truncate">{p.name}</p>
              <p className="text-xs text-slate-400">{p.category} · {p.weight} · {money(p.price)}{p.originalPrice ? ` (MRP ${money(p.originalPrice)})` : ''}</p>
            </div>
            <div className="flex items-center gap-2 flex-shrink-0">
              {!p.inStock && <span className={badge('bg-red-100 text-red-700')}>Out</span>}
              {p.isNew && <span className={badge('bg-blue-100 text-blue-700')}>New</span>}
              <button onClick={() => startEdit(p)} className="h-8 w-8 rounded-xl bg-slate-100 flex items-center justify-center hover:bg-slate-200"><Edit3 className="h-3.5 w-3.5 text-slate-600" /></button>
              <button onClick={() => { if (confirm('Delete this product?')) deleteDoc(doc(db, 'products', p.id)); }} className="h-8 w-8 rounded-xl hover:bg-red-50 flex items-center justify-center"><Trash2 className="h-3.5 w-3.5 text-red-500" /></button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════
   CUSTOMERS (search, order history)
   ═══════════════════════════════════════════ */
function Customers() {
  const [orders, setOrders] = useState<any[]>([]); const [search, setSearch] = useState(''); const [sel, setSel] = useState<any>(null);
  useEffect(() => onSnapshot(collection(db, 'orders'), s => { const a: any[] = []; s.forEach(d => a.push({ id: d.id, ...d.data() })); setOrders(a); }), []);

  // Build unique customer list from orders
  const customers = useMemo(() => {
    const map: Record<string, { name: string; email: string; phone: string; orders: number; totalSpent: number; lastOrder: string }> = {};
    orders.forEach(o => {
      const key = o.customer?.email || o.userEmail || o.userId;
      if (!key) return;
      if (!map[key]) map[key] = { name: o.customer?.name || o.userName || '', email: o.customer?.email || o.userEmail || '', phone: o.customer?.phone || '', orders: 0, totalSpent: 0, lastOrder: '' };
      map[key].orders++; map[key].totalSpent += o.totalAmount || 0;
      if (!map[key].lastOrder || o.createdAt > map[key].lastOrder) map[key].lastOrder = o.createdAt;
    });
    return Object.values(map).sort((a, b) => b.orders - a.orders);
  }, [orders]);

  const filtered = customers.filter(c => !search || [c.name, c.email, c.phone].some(f => f?.toLowerCase().includes(search.toLowerCase())));

  if (sel) {
    const custOrders = orders.filter(o => (o.customer?.email || o.userEmail) === sel.email).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    return (
      <div className="space-y-4">
        <button onClick={() => setSel(null)} className="flex items-center gap-1.5 text-sm text-slate-500 hover:text-slate-900"><ArrowLeft className="h-4 w-4" /> All Customers</button>
        <div className={`${card} p-6`}>
          <div className="flex items-center gap-4 mb-4">
            <div className="h-14 w-14 rounded-2xl bg-emerald-100 flex items-center justify-center text-emerald-700 text-xl font-bold">{sel.name.charAt(0)}</div>
            <div><p className="text-lg font-bold text-slate-900">{sel.name}</p><p className="text-sm text-slate-500">{sel.email}</p><p className="text-sm text-slate-500">{sel.phone}</p></div>
          </div>
          <div className="grid grid-cols-3 gap-3">
            <div className="bg-slate-50 rounded-xl p-3 text-center"><p className="text-lg font-bold text-slate-900">{sel.orders}</p><p className="text-[10px] text-slate-400 uppercase">Orders</p></div>
            <div className="bg-slate-50 rounded-xl p-3 text-center"><p className="text-lg font-bold text-slate-900">{money(sel.totalSpent)}</p><p className="text-[10px] text-slate-400 uppercase">Spent</p></div>
            <div className="bg-slate-50 rounded-xl p-3 text-center"><p className="text-lg font-bold text-slate-900">{money(Math.round(sel.totalSpent / sel.orders))}</p><p className="text-[10px] text-slate-400 uppercase">Avg Order</p></div>
          </div>
        </div>
        <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider">Order History</h2>
        <div className={`${card} overflow-hidden divide-y divide-slate-100`}>
          {custOrders.map(o => (
            <div key={o.id} className="px-5 py-3 flex items-center gap-3 text-sm">
              <span className="font-mono text-xs text-slate-400 w-20">#{o.orderId || o.id.slice(-6)}</span>
              <span className="flex-1">{o.items?.length} items</span>
              <span className="font-semibold">{money(o.totalAmount)}</span>
              <span className={badge(statusStyle[o.status] || '')}>{o.status}</span>
              <span className="text-xs text-slate-400">{fmt(o.createdAt).split(',')[0]}</span>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between"><h1 className="text-2xl font-bold text-slate-900">Customers ({customers.length})</h1>
        <button onClick={() => downloadCSV(customers.map(c => ({ Name: c.name, Email: c.email, Phone: c.phone, Orders: c.orders, TotalSpent: c.totalSpent })), 'customers.csv')} className={btn2}><Download className="h-4 w-4" /> Export</button>
      </div>
      <div className="relative"><Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" /><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search by name, email, phone…" className={`${input} pl-10`} /></div>
      <div className={`${card} overflow-hidden divide-y divide-slate-100`}>
        {filtered.length === 0 && <p className="p-10 text-center text-sm text-slate-400">No customers found</p>}
        {filtered.map(c => (
          <button key={c.email} onClick={() => setSel(c)} className="w-full text-left px-5 py-3.5 flex items-center gap-3 hover:bg-slate-50/80">
            <div className="h-10 w-10 rounded-xl bg-emerald-100 flex items-center justify-center text-emerald-700 text-sm font-bold flex-shrink-0">{c.name.charAt(0)}</div>
            <div className="flex-1 min-w-0"><p className="text-sm font-semibold text-slate-800 truncate">{c.name}</p><p className="text-xs text-slate-400">{c.email} · {c.phone}</p></div>
            <div className="text-right flex-shrink-0"><p className="text-sm font-bold text-slate-900">{c.orders} orders</p><p className="text-xs text-slate-400">{money(c.totalSpent)}</p></div>
            <ChevronRight className="h-4 w-4 text-slate-300 flex-shrink-0" />
          </button>
        ))}
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════
   SETTINGS (site config, coupons, gift cards, contact info)
   ═══════════════════════════════════════════ */
function SettingsPage() {
  const [tab, setTab] = useState<'site' | 'coupons' | 'giftcards'>('site');
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold text-slate-900">Settings</h1>
      <div className="flex gap-1.5">
        {[{ k: 'site', l: 'Site Config' }, { k: 'coupons', l: 'Coupons' }, { k: 'giftcards', l: 'Gift Cards' }].map(t => (
          <button key={t.k} onClick={() => setTab(t.k as any)} className={cn('px-4 py-2 rounded-xl text-sm font-semibold transition-colors', tab === t.k ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-500 hover:bg-slate-200')}>{t.l}</button>
        ))}
      </div>
      {tab === 'site' && <SiteConfig />}
      {tab === 'coupons' && <CouponsTab />}
      {tab === 'giftcards' && <GiftCardsTab />}
    </div>
  );
}

function SiteConfig() {
  const [cfg, setCfg] = useState<Record<string, string>>({}); const [cats, setCats] = useState<string[]>([]); const [newCat, setNewCat] = useState(''); const [busy, setBusy] = useState(false); const [loading, setLoading] = useState(true);
  useEffect(() => { Promise.all([getDoc(doc(db, 'config', 'site')), getDoc(doc(db, 'config', 'categories'))]).then(([s, c]) => { if (s.exists()) setCfg(s.data() as any); if (c.exists()) setCats(c.data().list || []); setLoading(false); }); }, []);
  const save = async () => { setBusy(true); await setDoc(doc(db, 'config', 'site'), cfg, { merge: true }); await setDoc(doc(db, 'config', 'categories'), { list: cats }); setBusy(false); };
  const brandFields = [['siteName', 'Brand Name'], ['logoUrl', 'Logo Icon URL'], ['logoTextUrl', 'Logo + Text URL'], ['heroTitle', 'Hero Title'], ['heroSubtitle', 'Hero Subtitle'], ['heroBadge', 'Hero Badge'], ['heroImage', 'Hero Image URL']];
  const contactFields = [['contactPhone', 'Phone Number'], ['contactEmail', 'Email Address'], ['contactAddress', 'Full Address'], ['contactCity', 'City'], ['contactHours', 'Working Hours'], ['upiId', 'UPI ID'], ['upiName', 'UPI Display Name']]; const deliveryFields = [['minFreeDelivery', 'Min Order for Free Delivery (₹)'], ['deliveryFee', 'Delivery Fee (₹)']];
  if (loading) return <div className="py-10 text-center"><Loader2 className="h-5 w-5 animate-spin text-slate-400 mx-auto" /></div>;
  return (
    <div className="max-w-2xl space-y-5">
      <div className={`${card} p-6 space-y-4`}><p className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5"><Phone className="h-3.5 w-3.5" /> Contact Information</p>
        {contactFields.map(([k, l]) => (<div key={k}><label className={label}>{l}</label><input value={cfg[k] || ''} onChange={e => setCfg({ ...cfg, [k]: e.target.value })} className={input} placeholder="" /></div>))}
      </div>
      <div className={`${card} p-6 space-y-4`}><p className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5"><Truck className="h-3.5 w-3.5" /> Delivery Settings</p><p className="text-xs text-slate-400 -mt-2">Orders above the minimum get free delivery.</p>{deliveryFields.map(([k, l]) => (<div key={k}><label className={label}>{l}</label><input type="number" value={cfg[k] || ''} onChange={e => setCfg({ ...cfg, [k]: e.target.value })} className={input} placeholder={k === 'minFreeDelivery' ? '499' : '49'} /></div>))}</div>
      <div className={`${card} p-6 space-y-4`}><p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Branding & Content</p><p className="text-xs text-slate-400 -mt-2">Changes update the live site instantly.</p>
        {brandFields.map(([k, l]) => (<div key={k}><label className={label}>{l}</label><input value={cfg[k] || ''} onChange={e => setCfg({ ...cfg, [k]: e.target.value })} className={input} /></div>))}
      </div>
      <div className={`${card} p-6 space-y-3`}><p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Product Categories</p>
        <div className="flex flex-wrap gap-2">{cats.map((c, i) => (<span key={c} className="inline-flex items-center gap-1 bg-slate-100 rounded-full px-3 py-1 text-xs font-medium text-slate-700">{c}<button onClick={() => { const a = [...cats]; a.splice(i, 1); setCats(a); }} className="text-red-400 hover:text-red-600"><X className="h-3 w-3" /></button></span>))}</div>
        <div className="flex gap-2"><input value={newCat} onChange={e => setNewCat(e.target.value)} onKeyDown={e => { if (e.key === 'Enter' && newCat.trim()) { setCats([...cats, newCat.trim()]); setNewCat(''); } }} placeholder="New category" className={`${input} max-w-xs`} /><button onClick={() => { if (newCat.trim()) { setCats([...cats, newCat.trim()]); setNewCat(''); } }} className={btn2}><Plus className="h-4 w-4" /></button></div>
      </div>
      <button onClick={save} disabled={busy} className={btn1}>{busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />} Save Settings</button>
    </div>
  );
}

function CouponsTab() {
  const [items, setItems] = useState<any[]>([]); const [show, setShow] = useState(false); const [form, setForm] = useState({ code: '', discount: '', type: 'percent', minOrder: '0', maxDiscount: '', usageLimit: '', perUserLimit: '1', expiresAt: '' }); const [busy, setBusy] = useState(false); const [err, setErr] = useState('');
  const [orders, setOrders] = useState<any[]>([]);
  useEffect(() => onSnapshot(collection(db, 'coupons'), s => { const a: any[] = []; s.forEach(d => a.push({ id: d.id, ...d.data() })); setItems(a); }), []);
  useEffect(() => onSnapshot(collection(db, 'orders'), s => { const a: any[] = []; s.forEach(d => a.push(d.data())); setOrders(a); }), []);
  const usage = (code: string) => orders.filter(o => o.couponCode === code && o.status !== 'cancelled').length;

  const save = async () => {
    if (!form.code || !form.discount) return; setErr('');
    if (items.find(c => c.id === form.code.toUpperCase())) { setErr('Code already exists'); return; }
    setBusy(true);
    const d: any = { discount: Number(form.discount), type: form.type, minOrder: Number(form.minOrder) || 0, active: true };
    if (form.maxDiscount) d.maxDiscount = Number(form.maxDiscount); if (form.usageLimit) d.usageLimit = Number(form.usageLimit); if (form.perUserLimit) d.perUserLimit = Number(form.perUserLimit); if (form.expiresAt) d.expiresAt = form.expiresAt;
    await setDoc(doc(db, 'coupons', form.code.toUpperCase()), d);
    setBusy(false); setShow(false); setForm({ code: '', discount: '', type: 'percent', minOrder: '0', maxDiscount: '', usageLimit: '', perUserLimit: '1', expiresAt: '' });
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between"><p className="text-sm font-bold text-slate-700">Coupons ({items.length})</p><button onClick={() => setShow(true)} className={btn1}><Plus className="h-4 w-4" /> Create</button></div>
      {show && (
        <div className={`${card} p-6 max-w-lg space-y-4`}>
          <p className="text-sm font-bold text-slate-900">New Coupon</p>
          <div className="grid grid-cols-2 gap-3">
            <div><label className={label}>Code</label><input value={form.code} onChange={e => setForm({ ...form, code: e.target.value.toUpperCase() })} className={`${input} font-mono`} placeholder="SAVE20" /></div>
            <div><label className={label}>Discount</label><input type="number" value={form.discount} onChange={e => setForm({ ...form, discount: e.target.value })} className={input} /></div>
            <div><label className={label}>Type</label><select value={form.type} onChange={e => setForm({ ...form, type: e.target.value })} className={input}><option value="percent">Percent %</option><option value="flat">Flat ₹</option></select></div>
            <div><label className={label}>Min Order ₹</label><input type="number" value={form.minOrder} onChange={e => setForm({ ...form, minOrder: e.target.value })} className={input} /></div>
            <div><label className={label}>Max Discount ₹</label><input type="number" value={form.maxDiscount} onChange={e => setForm({ ...form, maxDiscount: e.target.value })} className={input} placeholder="Optional" /></div>
            <div><label className={label}>Total Usage Limit</label><input type="number" value={form.usageLimit} onChange={e => setForm({ ...form, usageLimit: e.target.value })} className={input} placeholder="Unlimited" /></div>
            <div><label className={label}>Per User Limit</label><input type="number" value={form.perUserLimit} onChange={e => setForm({ ...form, perUserLimit: e.target.value })} className={input} placeholder="1" /></div>
            <div className="col-span-2"><label className={label}>Expires</label><input type="date" value={form.expiresAt} onChange={e => setForm({ ...form, expiresAt: e.target.value })} className={input} /></div>
          </div>
          {err && <p className="text-sm text-red-600">{err}</p>}
          <div className="flex gap-2"><button onClick={save} disabled={busy} className={btn1}>{busy ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Create'}</button><button onClick={() => setShow(false)} className={btn2}>Cancel</button></div>
        </div>
      )}
      <div className={`${card} overflow-hidden divide-y divide-slate-100`}>
        {items.length === 0 && <p className="p-10 text-center text-sm text-slate-400">No coupons</p>}
        {items.map(c => {
          const u = usage(c.id); const expired = c.expiresAt && new Date(c.expiresAt) < new Date(); const maxed = c.usageLimit && u >= c.usageLimit;
          return (
            <div key={c.id} className="px-5 py-3.5 flex items-center gap-3">
              <div className="flex-1">
                <div className="flex items-center gap-2"><span className="text-sm font-mono font-bold text-slate-800">{c.id}</span>
                  {expired && <span className={badge('bg-red-100 text-red-700')}>Expired</span>}
                  {maxed && <span className={badge('bg-amber-100 text-amber-700')}>Limit</span>}
                </div>
                <p className="text-xs text-slate-400 mt-0.5">{c.type === 'percent' ? `${c.discount}%` : money(c.discount)} off · Min {money(c.minOrder)}{c.maxDiscount ? ` · Max ${money(c.maxDiscount)}` : ''} · Used {u}{c.usageLimit ? `/${c.usageLimit}` : 'x'} · {c.perUserLimit ? `${c.perUserLimit}/user` : 'No user limit'}{c.expiresAt ? ` · Exp ${c.expiresAt}` : ''}</p>
              </div>
              <button onClick={() => updateDoc(doc(db, 'coupons', c.id), { active: !c.active })} className={cn('text-xs font-bold uppercase px-3 py-1.5 rounded-full transition-colors', c.active ? 'bg-emerald-100 text-emerald-700 hover:bg-emerald-200' : 'bg-slate-100 text-slate-500 hover:bg-slate-200')}>{c.active ? 'Active' : 'Off'}</button>
              <button onClick={() => { if (confirm('Delete coupon?')) deleteDoc(doc(db, 'coupons', c.id)); }} className="h-8 w-8 rounded-xl hover:bg-red-50 flex items-center justify-center"><Trash2 className="h-3.5 w-3.5 text-red-500" /></button>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function GiftCardsTab() {
  const [items, setItems] = useState<any[]>([]); const [show, setShow] = useState(false); const [code, setCode] = useState(''); const [balance, setBalance] = useState('');
  useEffect(() => onSnapshot(collection(db, 'giftcards'), s => { const a: any[] = []; s.forEach(d => a.push({ id: d.id, ...d.data() })); setItems(a); }), []);
  const gen = () => { const ch = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; let c = ''; for (let i = 0; i < 16; i++) { c += ch[Math.floor(Math.random() * ch.length)]; if (i === 3 || i === 7 || i === 11) c += '-'; } setCode(c); };
  const save = async () => { if (!code || !balance) return; await setDoc(doc(db, 'giftcards', code.toUpperCase()), { balance: Number(balance), active: true }); setShow(false); setCode(''); setBalance(''); };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between"><p className="text-sm font-bold text-slate-700">Gift Cards ({items.length})</p><button onClick={() => { setShow(true); gen(); }} className={btn1}><Plus className="h-4 w-4" /> Generate</button></div>
      {show && (
        <div className={`${card} p-6 max-w-sm space-y-4`}>
          <p className="text-sm font-bold text-slate-900">New Gift Card</p>
          <div><label className={label}>Code</label><div className="flex gap-2"><input value={code} onChange={e => setCode(e.target.value.toUpperCase())} className={`${input} font-mono`} /><button onClick={gen} className={btn2}>Random</button></div></div>
          <div><label className={label}>Balance ₹</label><input type="number" value={balance} onChange={e => setBalance(e.target.value)} className={input} placeholder="500" /></div>
          <div className="flex gap-2"><button onClick={save} className={btn1}>Create</button><button onClick={() => setShow(false)} className={btn2}>Cancel</button></div>
        </div>
      )}
      <div className={`${card} overflow-hidden divide-y divide-slate-100`}>
        {items.length === 0 && <p className="p-10 text-center text-sm text-slate-400">No gift cards</p>}
        {items.map(c => (
          <div key={c.id} className="px-5 py-3.5 flex items-center gap-3">
            <div className="flex-1"><p className="text-sm font-mono font-bold text-slate-800">{c.id}</p><p className="text-xs text-slate-400 mt-0.5">Balance: {money(c.balance)}</p></div>
            <span className={cn('text-xs font-bold uppercase px-3 py-1.5 rounded-full', c.active ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700')}>{c.active ? 'Active' : 'Used'}</span>
            <button onClick={() => { if (confirm('Delete?')) deleteDoc(doc(db, 'giftcards', c.id)); }} className="h-8 w-8 rounded-xl hover:bg-red-50 flex items-center justify-center"><Trash2 className="h-3.5 w-3.5 text-red-500" /></button>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════
   REPLACEMENTS (admin can accept/reject/reship)
   ═══════════════════════════════════════════ */
// Replacement statuses: requested → accepted/rejected → reshipped
const replColors: Record<string, string> = { requested: 'bg-amber-100 text-amber-700', accepted: 'bg-emerald-100 text-emerald-700', rejected: 'bg-red-100 text-red-700', reshipped: 'bg-blue-100 text-blue-700' };

function Replacements() {
  const [orders, setOrders] = useState<any[]>([]);
  const [updating, setUpdating] = useState('');
  useEffect(() => onSnapshot(collection(db, 'orders'), s => { const a: any[] = []; s.forEach(d => a.push({ id: d.id, ...d.data() })); setOrders(a); }), []);
  const replacements = orders.filter(o => o.replacementRequested).sort((a, b) => new Date(b.replacementRequestedAt || b.createdAt).getTime() - new Date(a.replacementRequestedAt || a.createdAt).getTime());

  const changeReplStatus = async (id: string, status: string) => {
    setUpdating(id);
    await updateDoc(doc(db, 'orders', id), { replacementStatus: status, [`replacement_${status}_at`]: new Date().toISOString() });
    setUpdating('');
  };

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold text-slate-900">Replacements ({replacements.length})</h1>
      <div className={`${card} overflow-hidden divide-y divide-slate-100`}>
        {replacements.length === 0 && <p className="p-10 text-center text-sm text-slate-400">No replacement requests</p>}
        {replacements.map(o => {
          const rs = o.replacementStatus || 'requested';
          return (
            <div key={o.id} className="px-5 py-4 space-y-3">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs font-mono text-slate-400">#{o.orderId || o.id.slice(-6)}</span>
                    <span className={badge(replColors[rs] || 'bg-slate-100 text-slate-600')}>{rs}</span>
                  </div>
                  <p className="text-sm font-semibold text-slate-800">{o.customer?.name} · {money(o.totalAmount)}</p>
                  <p className="text-xs text-slate-400 mt-0.5">Requested: {o.replacementRequestedAt ? fmt(o.replacementRequestedAt) : '—'}</p>
                </div>
                {/* Status actions */}
                <div className="flex gap-1.5 flex-shrink-0">
                  {rs === 'requested' && <>
                    <button onClick={() => changeReplStatus(o.id, 'accepted')} disabled={updating === o.id} className="bg-emerald-50 text-emerald-700 text-xs font-semibold px-3 py-1.5 rounded-xl hover:bg-emerald-100 disabled:opacity-50">Accept</button>
                    <button onClick={() => changeReplStatus(o.id, 'rejected')} disabled={updating === o.id} className="bg-red-50 text-red-600 text-xs font-semibold px-3 py-1.5 rounded-xl hover:bg-red-100 disabled:opacity-50">Reject</button>
                  </>}
                  {rs === 'accepted' && <button onClick={() => changeReplStatus(o.id, 'reshipped')} disabled={updating === o.id} className="bg-blue-50 text-blue-700 text-xs font-semibold px-3 py-1.5 rounded-xl hover:bg-blue-100 disabled:opacity-50"><Truck className="h-3 w-3 inline mr-1" />Reship</button>}
                  {rs === 'reshipped' && <span className="text-xs text-emerald-600 font-semibold">Shipped ✓</span>}
                  {rs === 'rejected' && <span className="text-xs text-red-500 font-semibold">Closed</span>}
                </div>
              </div>
              {o.replacementReason && (
                <div className="bg-slate-50 rounded-xl px-3 py-2"><p className="text-[10px] text-slate-400 font-semibold uppercase">Reason</p><p className="text-sm text-slate-700">{o.replacementReason}</p></div>
              )}
              <p className="text-xs text-slate-400">Items: {o.items?.map((i: any) => i.name).join(', ')}</p>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════
   LAYOUT — top bar for main nav, sidebar for secondary
   ═══════════════════════════════════════════ */
type Page = 'dashboard' | 'orders' | 'products' | 'customers' | 'replacements' | 'settings';
const topNav: { label: string; page: Page; icon: typeof LayoutDashboard }[] = [
  { label: 'Dashboard', page: 'dashboard', icon: LayoutDashboard },
  { label: 'Orders', page: 'orders', icon: ShoppingCart },
  { label: 'Replacements', page: 'replacements', icon: RotateCcw },
];
const sideNav: { label: string; page: Page; icon: typeof LayoutDashboard }[] = [
  { label: 'Products', page: 'products', icon: Package },
  { label: 'Customers', page: 'customers', icon: Users },
  { label: 'Settings', page: 'settings', icon: Settings },
];

function Layout() {
  const [page, setPage] = useState<Page>('dashboard');
  const [sideOpen, setSideOpen] = useState(false);
  const [siteCfg, setSiteCfg] = useState<any>({});
  const goTo = (p: string) => { setPage(p as Page); setSideOpen(false); };
  useEffect(() => onSnapshot(doc(db, 'config', 'site'), s => { if (s.exists()) setSiteCfg(s.data()); }), []);

  const logoUrl = siteCfg.logoUrl || '';
  const brandName = siteCfg.siteName || 'Admin';

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="fixed inset-x-0 top-0 z-40 bg-white/95 backdrop-blur-sm border-b border-slate-200/80">
        <div className="max-w-6xl mx-auto flex items-center justify-between px-4 h-14">
          <div className="flex items-center gap-2.5">
            <img src={logoUrl} alt="" className="h-8 w-8 rounded-xl object-contain" />
            <div><p className="text-sm font-bold text-slate-900 leading-tight">{brandName}</p><p className="text-[9px] uppercase tracking-widest text-slate-400 leading-tight">Admin</p></div>
          </div>
          <div className="flex items-center gap-2">
            {/* Sidebar toggle for Products/Customers/Settings */}
            <button onClick={() => setSideOpen(!sideOpen)} className="flex items-center gap-1.5 text-xs text-slate-500 font-semibold bg-slate-100 px-3 py-1.5 rounded-xl hover:bg-slate-200">
              <MenuIcon className="h-3.5 w-3.5" /> More
            </button>
          </div>
        </div>
        {/* Main tabs */}
        <div className="max-w-6xl mx-auto overflow-x-auto scrollbar-none">
          <div className="flex px-4 pb-2 gap-1 min-w-max">
            {topNav.map(n => (
              <button key={n.page} onClick={() => goTo(n.page)}
                className={cn('flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all',
                  page === n.page ? 'bg-emerald-600 text-white shadow-sm shadow-emerald-200' : 'text-slate-500 hover:text-slate-800 hover:bg-slate-100')}>
                <n.icon className="h-3.5 w-3.5" /> {n.label}
              </button>
            ))}
            {/* Show active side nav page as a tab too */}
            {sideNav.some(n => n.page === page) && (
              <span className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold bg-emerald-600 text-white shadow-sm">
                {sideNav.find(n => n.page === page)!.label}
              </span>
            )}
          </div>
        </div>
      </header>

      {/* Side panel overlay for Products/Customers/Settings */}
      {sideOpen && (
        <>
          <div className="fixed inset-0 z-40 bg-black/10" onClick={() => setSideOpen(false)} />
          <div className="fixed top-0 right-0 bottom-0 z-50 w-56 bg-white border-l border-slate-200 shadow-xl">
            <div className="flex items-center justify-between px-4 h-14 border-b border-slate-100">
              <p className="text-sm font-bold text-slate-900">Manage</p>
              <button onClick={() => setSideOpen(false)} className="h-8 w-8 flex items-center justify-center rounded-xl hover:bg-slate-100"><X className="h-4 w-4 text-slate-500" /></button>
            </div>
            <nav className="p-3 space-y-1">
              {sideNav.map(n => (
                <button key={n.page} onClick={() => goTo(n.page)}
                  className={cn('w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all',
                    page === n.page ? 'bg-emerald-600 text-white' : 'text-slate-600 hover:bg-slate-100')}>
                  <n.icon className="h-4 w-4" /> {n.label}
                </button>
              ))}
              <div className="border-t border-slate-100 mt-3 pt-3">
                <button onClick={() => signOut(adminAuth)} className="w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium text-red-500 hover:bg-red-50"><LogOut className="h-4 w-4" /> Sign Out</button>
              </div>
            </nav>
          </div>
        </>
      )}

      <main className="max-w-6xl mx-auto px-4 pt-28 pb-8">
        {page === 'dashboard' && <Dashboard goTo={goTo} />}
        {page === 'orders' && <Orders />}
        {page === 'products' && <Products />}
        {page === 'customers' && <Customers />}
        {page === 'replacements' && <Replacements />}
        {page === 'settings' && <SettingsPage />}
      </main>
    </div>
  );
}

/* ═══════════════════════════════════════════
   EXPORT
   ═══════════════════════════════════════════ */
interface Props { onBack?: () => void; }

export default function AdminPanel(_props: Props) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => onAuthStateChanged(adminAuth, async u => {
    if (u) {
      const snap = await getDoc(doc(db, 'config', 'admins'));
      if (snap.exists() && snap.data().uids?.includes(u.uid)) setUser(u);
      else { await signOut(adminAuth); setUser(null); }
    } else setUser(null);
    setLoading(false);
  }), []);

  if (loading) return <div className="min-h-screen flex items-center justify-center bg-slate-50"><Loader2 className="h-6 w-6 animate-spin text-emerald-500" /></div>;

  return !user ? <LoginScreen /> : <Layout />;
}
